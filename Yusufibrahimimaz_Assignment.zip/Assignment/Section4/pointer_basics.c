/*
 * pointer_basics.c
 * CampusPe Cybersecurity Assignment - Section 4, Task 4.1
 *
 * Demonstrates basic pointer concepts in C:
 *   - Creating a pointer to an integer
 *   - Accessing a value through a pointer (dereferencing)
 *   - Modifying a value through a pointer
 *
 * Compile : gcc pointer_basics.c -o pointer_basics
 * Run     : ./pointer_basics
 */

#include <stdio.h>

int main(void)
{
    /* ── Step 1: Create the integer variable ────────────────────────── */
    int port = 80;

    /* ── Step 2: Create a pointer that stores the ADDRESS of port ───── */
    int *ptr = &port;

    printf("========================================\n");
    printf("  Pointer Basics Demo - Port Variable\n");
    printf("========================================\n\n");

    /* ── Step 3: Print value using the variable directly ────────────── */
    printf("  [Direct]  port = %d\n", port);

    /* ── Step 4: Print value using the pointer (dereference with *) ─── */
    printf("  [Pointer] *ptr = %d\n", *ptr);

    /* Show memory addresses for educational context */
    printf("\n  Memory address of port : %p\n", (void *)&port);
    printf("  Value stored in ptr    : %p\n", (void *)ptr);
    printf("  (Both should be the same address)\n");

    /* ── Step 5: Change port to 443 THROUGH the pointer ─────────────── */
    *ptr = 443;

    printf("\n  --- After modifying via pointer ---\n\n");
    printf("  [Direct]  port = %d\n", port);
    printf("  [Pointer] *ptr = %d\n", *ptr);

    printf("\n========================================\n");
    printf("  Key Concepts:\n");
    printf("  &port  -> address of the variable\n");
    printf("  ptr    -> holds that address\n");
    printf("  *ptr   -> value AT that address\n");
    printf("========================================\n\n");

    return 0;
}
