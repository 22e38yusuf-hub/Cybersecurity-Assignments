#!/usr/bin/env python3
"""
network_scanner.py - TCP Port Scanner
CampusPe Cybersecurity Assignment - Section 2, Task 2.2

Usage:
    python3 network_scanner.py <target_ip> [port1,port2,...]

Examples:
    python3 network_scanner.py 127.0.0.1
    python3 network_scanner.py 192.168.1.1 22,80,443,3306,8080
"""

import socket
import sys
import time
from datetime import datetime

# ── ANSI colours ─────────────────────────────────────────────────────────────
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

# Common port → service name mapping
SERVICE_MAP = {
    21:   "FTP",
    22:   "SSH",
    23:   "Telnet",
    25:   "SMTP",
    53:   "DNS",
    80:   "HTTP",
    110:  "POP3",
    143:  "IMAP",
    443:  "HTTPS",
    445:  "SMB",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    6379: "Redis",
    8080: "HTTP-Alt",
    8443: "HTTPS-Alt",
    27017:"MongoDB",
}

DEFAULT_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445,
                 3306, 3389, 5432, 8080, 8443]
TIMEOUT       = 1.0   # seconds per connection attempt
OUTPUT_FILE   = "scan_results.txt"


def get_service(port: int) -> str:
    """Return human-readable service name for a port."""
    return SERVICE_MAP.get(port, "Unknown")


def scan_port(host: str, port: int, timeout: float = TIMEOUT) -> tuple:
    """
    Attempt a TCP connection to host:port.
    Returns (port, status, banner) where status is 'OPEN' or 'CLOSED'.
    """
    banner = ""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        if result == 0:
            # Try to grab a banner (best effort)
            try:
                sock.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                raw = sock.recv(1024).decode("utf-8", errors="ignore").strip()
                banner = raw.split("\n")[0][:60] if raw else ""
            except Exception:
                pass
            sock.close()
            return port, "OPEN", banner
        else:
            sock.close()
            return port, "CLOSED", ""
    except socket.error:
        return port, "CLOSED", ""


def parse_ports(port_arg: str) -> list:
    """Parse a comma-separated port string into a sorted list of ints."""
    try:
        ports = [int(p.strip()) for p in port_arg.split(",")]
        return sorted(set(p for p in ports if 0 < p < 65536))
    except ValueError:
        print(f"{RED}[!] Invalid port list: {port_arg}{RESET}")
        sys.exit(1)


def print_banner(target: str, ports: list) -> None:
    print(f"\n{BOLD}{CYAN}{'='*56}{RESET}")
    print(f"{BOLD}{CYAN}   Network Port Scanner{RESET}")
    print(f"{BOLD}{CYAN}{'='*56}{RESET}")
    print(f"  Target  : {target}")
    print(f"  Ports   : {len(ports)} ports queued")
    print(f"  Started : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{BOLD}{CYAN}{'='*56}{RESET}\n")


def main():
    # ── Argument handling ──────────────────────────────────────────────────
    if len(sys.argv) < 2:
        print(f"\n{YELLOW}Usage: python3 network_scanner.py <target_ip> [port1,port2,...]{RESET}")
        print(f"Example: python3 network_scanner.py 127.0.0.1 22,80,443,3306\n")
        sys.exit(1)

    target = sys.argv[1]
    ports  = parse_ports(sys.argv[2]) if len(sys.argv) >= 3 else DEFAULT_PORTS

    # Resolve hostname to IP
    try:
        resolved_ip = socket.gethostbyname(target)
    except socket.gaierror:
        print(f"{RED}[!] Cannot resolve host: {target}{RESET}")
        sys.exit(1)

    print_banner(resolved_ip, ports)

    # ── Scan ──────────────────────────────────────────────────────────────
    start_time   = time.time()
    open_ports   = []
    closed_ports = []
    results_log  = []

    for port in ports:
        service = get_service(port)
        port_num, status, banner = scan_port(resolved_ip, port)

        if status == "OPEN":
            open_ports.append(port_num)
            colour = GREEN
            marker = "OPEN  "
        else:
            closed_ports.append(port_num)
            colour = RED
            marker = "CLOSED"

        line = f"  Port {port_num:<6} ({service:<12}) : {colour}{marker}{RESET}"
        if banner:
            line += f"  [{banner[:40]}]"
        print(line)

        log_line = f"Port {port_num:<6} ({service:<12}) : {marker}"
        if banner:
            log_line += f"  [{banner[:40]}]"
        results_log.append(log_line)

    elapsed = time.time() - start_time

    # ── Summary ──────────────────────────────────────────────────────────
    summary = (
        f"\n{'='*56}\n"
        f"  SCAN COMPLETE\n"
        f"  Target          : {resolved_ip}\n"
        f"  Ports Scanned   : {len(ports)}\n"
        f"  Open Ports      : {len(open_ports)}\n"
        f"  Closed Ports    : {len(closed_ports)}\n"
        f"  Scan Duration   : {elapsed:.2f} seconds\n"
        f"{'='*56}\n"
    )
    print(summary)

    if open_ports:
        print(f"  {GREEN}Open ports: {', '.join(map(str, open_ports))}{RESET}\n")

    # ── Save to file ──────────────────────────────────────────────────────
    with open(OUTPUT_FILE, "w") as f:
        f.write("=" * 56 + "\n")
        f.write("  Network Port Scan Results\n")
        f.write("=" * 56 + "\n")
        f.write(f"  Target          : {resolved_ip}\n")
        f.write(f"  Scan Date       : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"  Ports Queued    : {len(ports)}\n")
        f.write("=" * 56 + "\n\n")
        for line in results_log:
            f.write(line + "\n")
        f.write("\n")
        f.write("=" * 56 + "\n")
        f.write("  SUMMARY\n")
        f.write(f"  Open Ports    : {len(open_ports)}\n")
        if open_ports:
            f.write(f"  Open List     : {', '.join(map(str, open_ports))}\n")
        f.write(f"  Closed Ports  : {len(closed_ports)}\n")
        f.write(f"  Scan Duration : {elapsed:.2f} seconds\n")
        f.write("=" * 56 + "\n")

    print(f"  Results saved to: {BOLD}{OUTPUT_FILE}{RESET}\n")


if __name__ == "__main__":
    main()
