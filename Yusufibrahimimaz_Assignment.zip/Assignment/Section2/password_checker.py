#!/usr/bin/env python3
"""
password_checker.py - Password Strength Checker
CampusPe Cybersecurity Assignment - Section 2, Task 2.1

Checks a password for strength based on:
  - Length (minimum 8 characters)
  - Uppercase letters
  - Lowercase letters
  - Digits
  - Special characters

Scoring:
  0-2 criteria met -> Weak
  3-4 criteria met -> Medium
  5   criteria met -> Strong
"""

import re
import sys


# ── ANSI colour helpers ─────────────────────────────────────────────────────
RED    = "\033[91m"
YELLOW = "\033[93m"
GREEN  = "\033[92m"
CYAN   = "\033[96m"
RESET  = "\033[0m"
BOLD   = "\033[1m"


def check_password(password: str) -> dict:
    """
    Analyse the password against five criteria and return a results dict.
    """
    results = {
        "length":    len(password) >= 8,
        "uppercase": bool(re.search(r"[A-Z]", password)),
        "lowercase": bool(re.search(r"[a-z]", password)),
        "digits":    bool(re.search(r"\d", password)),
        "special":   bool(re.search(r"[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]", password)),
    }
    results["score"] = sum(results[k] for k in ["length", "uppercase",
                                                  "lowercase", "digits", "special"])
    return results


def classify_strength(score: int) -> tuple:
    """
    Return (label, colour) for a given score.
    """
    if score <= 2:
        return "WEAK",   RED
    elif score <= 4:
        return "MEDIUM", YELLOW
    else:
        return "STRONG", GREEN


def build_recommendations(results: dict) -> list:
    """
    Build a list of actionable recommendations for failed criteria.
    """
    recs = []
    if not results["length"]:
        recs.append("• Use at least 8 characters (longer is better – aim for 12+)")
    if not results["uppercase"]:
        recs.append("• Add at least one UPPERCASE letter (A-Z)")
    if not results["lowercase"]:
        recs.append("• Add at least one lowercase letter (a-z)")
    if not results["digits"]:
        recs.append("• Include at least one digit (0-9)")
    if not results["special"]:
        recs.append("• Include at least one special character  e.g. ! @ # $ % ^ & *")
    if not recs:
        recs.append("• Excellent! Your password meets all criteria.")
    return recs


def display_results(password: str, results: dict) -> None:
    """
    Pretty-print the analysis to stdout.
    """
    label, colour = classify_strength(results["score"])
    score         = results["score"]

    print()
    print(f"{BOLD}{CYAN}{'='*50}{RESET}")
    print(f"{BOLD}{CYAN}   Password Strength Checker - Results{RESET}")
    print(f"{BOLD}{CYAN}{'='*50}{RESET}")

    # Masked password display
    masked = password[0] + "*" * (len(password) - 2) + password[-1] if len(password) > 2 else "***"
    print(f"\n  Password : {masked}")
    print(f"  Length   : {len(password)} characters\n")

    print(f"{'─'*50}")
    print(f"  Criteria Check:")
    print(f"{'─'*50}")

    criteria = [
        ("Minimum 8 characters",  results["length"]),
        ("Uppercase letter (A-Z)", results["uppercase"]),
        ("Lowercase letter (a-z)", results["lowercase"]),
        ("Digit (0-9)",            results["digits"]),
        ("Special character",      results["special"]),
    ]

    for name, passed in criteria:
        tick = f"{GREEN}✓{RESET}" if passed else f"{RED}✗{RESET}"
        print(f"  {tick}  {name}")

    print(f"{'─'*50}")
    print(f"  Score    : {score} / 5")
    print(f"  Strength : {colour}{BOLD}{label}{RESET}")
    print(f"{'─'*50}")

    recs = build_recommendations(results)
    if recs[0] != "• Excellent! Your password meets all criteria.":
        print(f"\n  {YELLOW}Recommendations:{RESET}")
    else:
        print(f"\n  {GREEN}Recommendations:{RESET}")
    for rec in recs:
        print(f"  {rec}")

    print(f"\n{BOLD}{CYAN}{'='*50}{RESET}\n")


def main():
    print(f"\n{BOLD}{CYAN}  === Password Strength Checker ==={RESET}")
    print("  (Type 'quit' to exit)\n")

    while True:
        try:
            password = input("  Enter password to check: ")
        except (EOFError, KeyboardInterrupt):
            print("\n  Exiting. Stay secure!")
            sys.exit(0)

        if password.lower() == "quit":
            print("  Exiting. Stay secure!")
            break

        if not password:
            print(f"  {RED}Error: Password cannot be empty.{RESET}\n")
            continue

        results = check_password(password)
        display_results(password, results)


if __name__ == "__main__":
    main()
