===============================================================
  CampusPe Cybersecurity Assignment – README
===============================================================

Name        : Yusuf Ibrahim Imaz
Course      : Foundations of Ethical Hacking
Platform    : CampusPe Cybersecurity Training Program
Date        : 2026-04-13

===============================================================
  SUBMISSION NOTES
===============================================================

All code was developed and tested on Ubuntu 24 (LTS).
For Sections 3.2, 5.1 and 6.1, screenshots of actual command
output on your own machine should be inserted into the PDFs.

---------------------------------------------------------------
  SECTION OVERVIEW
---------------------------------------------------------------

Section 1 – Linux & Bash Scripting
  section1_commands.txt  : 10 Linux commands with explanations
  port_report.sh         : Bash port scanner (ports 21,22,80,443,3306)

Section 2 – Python Security Scripting
  password_checker.py    : Interactive password strength checker
  network_scanner.py     : TCP port scanner with file output
  scan_results.txt       : Sample scan output

Section 3 – Networking Basics
  section3_networking.pdf : OSI Model, IP addressing, protocols,
                            practical network analysis (with screenshots)

Section 4 – C Programming
  pointer_basics.c       : Pointer demonstration
  buffer_test.c          : Buffer overflow demo (educational)
  c_port_scanner.c       : TCP port scanner using POSIX sockets

Section 5 – Nmap & Lua NSE
  section5_nmap.pdf      : 5 Nmap scans on scanme.nmap.org (with screenshots)
  http-server-info.nse   : Custom Lua NSE script for server info

Section 6 – JavaScript & XSS
  section6_xss.pdf       : 5 XSS payloads tested on Juice Shop (with screenshots)
  keylogger.html         : Educational keylogger demonstration

Section 7 (Bonus) – Security Audit Tool
  security_audit.py      : Python security audit tool
  sample_report.html     : Sample HTML audit report

---------------------------------------------------------------
  HOW TO RUN EACH DELIVERABLE
---------------------------------------------------------------

# Section 1
chmod +x Section1/port_report.sh
./Section1/port_report.sh 192.168.1.1

# Section 2
python3 Section2/password_checker.py
python3 Section2/network_scanner.py 192.168.1.1 22,80,443,3306

# Section 4
cd Section4
gcc pointer_basics.c  -o pointer_basics  && ./pointer_basics
gcc -fno-stack-protector buffer_test.c -o buffer_test && ./buffer_test
gcc c_port_scanner.c  -o c_port_scanner  && ./c_port_scanner

# Section 5 (requires Nmap installed)
nmap --script=./Section5/http-server-info.nse scanme.nmap.org

# Section 6
Open Section6/keylogger.html in any modern browser

# Section 7 (Bonus)
python3 Section7/security_audit.py 192.168.1.1

---------------------------------------------------------------
  ACADEMIC INTEGRITY DECLARATION
---------------------------------------------------------------

I declare that this is my own work. No code has been shared with
or copied from other students. Use of AI assistance has been
disclosed as required.

Signature: yusufibrahimimaz   Date: 14/04/2026

===============================================================
