-- http-server-info.nse
-- CampusPe Cybersecurity Assignment - Section 5, Task 5.2
--
-- Purpose : Connects to an HTTP server, retrieves the root page,
--           and reports the Server header, HTTP status code, and
--           HTML page title.
--
-- Usage   : nmap --script=./http-server-info.nse <target>
--           nmap --script=./http-server-info.nse -p 80,8080 scanme.nmap.org
--
-- Author  : CampusPe Assignment
-- License : Same as Nmap – see https://nmap.org/book/man-legal.html

-- ── NSE library imports ────────────────────────────────────────────────────
local http    = require "http"
local shortport = require "shortport"
local stdnse  = require "stdnse"
local string  = require "string"

-- ── Script metadata ────────────────────────────────────────────────────────
description = [[
Sends an HTTP GET request to the root path ("/") of a web server and
extracts useful information:
  * HTTP status code and reason phrase
  * Server header (web server software / version)
  * HTML page title (from <title> tag if present)

This is useful for quick reconnaissance – identifying the web server
technology stack without intrusive probing.
]]

-- References to related vulnerability databases / standards
---@usage nmap --script=http-server-info <target>
---@usage nmap --script=http-server-info -p 80,8080,8443 <target>

-- Determines which ports this script runs against
-- shortport.http matches ports 80, 8080, 8888, 443, 8443, etc.
portrule = shortport.http

-- ── Helper: extract page title ─────────────────────────────────────────────
local function get_title(body)
    if not body then return nil end
    -- Case-insensitive match for <title>...</title>
    local title = body:match("<[Tt][Ii][Tt][Ll][Ee]>(.-)<%/[Tt][Ii][Tt][Ll][Ee]>")
    if title then
        -- Collapse whitespace and trim
        title = title:gsub("%s+", " "):match("^%s*(.-)%s*$")
        -- Truncate if very long
        if #title > 80 then
            title = title:sub(1, 77) .. "..."
        end
        return title
    end
    return nil
end

-- ── Helper: extract Server header ──────────────────────────────────────────
local function get_server_header(response)
    if response and response.header then
        return response.header["server"]
    end
    return nil
end

-- ── Main action function ───────────────────────────────────────────────────
action = function(host, port)
    -- Build output table (NSE key-value output)
    local output = stdnse.output_table()

    -- Perform HTTP GET request to root "/"
    local response = http.get(host, port, "/", {
        header = {
            ["User-Agent"] = "Nmap NSE http-server-info/1.0",
            ["Accept"]     = "text/html,application/xhtml+xml,*/*",
        },
        timeout = 8000,   -- 8 seconds
    })

    -- Check we got a valid response
    if not response then
        stdnse.debug1("No response received from %s:%d", host.ip, port.number)
        return nil
    end

    -- ── 1. HTTP Status Code ──────────────────────────────────────────────
    if response.status then
        output["Status Code"] = tostring(response.status)
                                 .. (response.status_line
                                     and (" | " .. response.status_line:match("HTTP/%S+%s+(.+)$") or "")
                                     or "")
    else
        output["Status Code"] = "Unknown"
    end

    -- ── 2. Server Header ────────────────────────────────────────────────
    local server = get_server_header(response)
    if server and server ~= "" then
        output["Server"] = server
    else
        output["Server"] = "(not disclosed)"
    end

    -- ── 3. Page Title ────────────────────────────────────────────────────
    local title = get_title(response.body)
    if title and title ~= "" then
        output["Page Title"] = title
    else
        output["Page Title"] = "(no <title> found)"
    end

    -- ── 4. Content-Type (bonus info) ─────────────────────────────────────
    if response.header and response.header["content-type"] then
        output["Content-Type"] = response.header["content-type"]
    end

    -- ── 5. Interesting headers hint ──────────────────────────────────────
    local interesting = {}
    local check_headers = { "x-powered-by", "x-generator", "x-frame-options",
                             "x-xss-protection", "strict-transport-security" }
    for _, hdr in ipairs(check_headers) do
        if response.header and response.header[hdr] then
            table.insert(interesting, hdr .. ": " .. response.header[hdr])
        end
    end
    if #interesting > 0 then
        output["Security Headers"] = table.concat(interesting, " | ")
    end

    return output
end
