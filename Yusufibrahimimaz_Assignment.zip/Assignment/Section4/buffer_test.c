/*
 * buffer_test.c
 * CampusPe Cybersecurity Assignment - Section 4, Task 4.2
 *
 * Demonstrates a classic stack-based buffer overflow vulnerability.
 *
 * WARNING: This code is intentionally UNSAFE for educational purposes only.
 *          Never use strcpy() with untrusted input in production code.
 *
 * Compile (with stack protection DISABLED to observe overflow):
 *   gcc -fno-stack-protector -z execstack -o buffer_test buffer_test.c
 *
 * Compile (normal – stack canary may catch the overflow):
 *   gcc buffer_test.c -o buffer_test
 *
 * Run: ./buffer_test
 */

#include <stdio.h>
#include <string.h>   /* strcpy, strlen */
#include <stdlib.h>

/* ── Helper: print a visual separator ───────────────────────────────────── */
void separator(void) { printf("\n%s\n", "----------------------------------------"); }

int main(void)
{
    /*
     * VULNERABILITY: buffer is only 16 bytes, but we accept unlimited input.
     * Any input longer than 15 characters (+1 null terminator) overflows the
     * buffer and corrupts adjacent memory on the stack.
     */
    char buffer[16];              /* <-- fixed-size stack buffer (only 16 bytes) */
    char admin_flag[] = "NORMAL"; /* lives right next to buffer on the stack    */

    printf("========================================\n");
    printf("  Buffer Overflow Demonstration\n");
    printf("  (Educational - do NOT use in prod)\n");
    printf("========================================\n");

    printf("\n  Buffer size      : %lu bytes\n", sizeof(buffer));
    printf("  Buffer address   : %p\n", (void *)buffer);
    printf("  admin_flag addr  : %p\n", (void *)admin_flag);
    separator();

    printf("\n  Enter some text (try short AND long inputs):\n  > ");
    fflush(stdout);

    /* ── UNSAFE: strcpy does NOT check destination buffer size ─────────── */
    char input[256];
    if (fgets(input, sizeof(input), stdin) != NULL) {
        /* Strip newline */
        size_t len = strlen(input);
        if (len > 0 && input[len - 1] == '\n') input[len - 1] = '\0';

        /* <<< INTENTIONAL VULNERABILITY >>> */
        strcpy(buffer, input);   /* dangerous: no bounds check */
    }

    separator();
    printf("\n  You entered     : \"%s\"\n", buffer);
    printf("  admin_flag      : \"%s\"\n", admin_flag);
    printf("\n========================================\n\n");

    return 0;
}

/*
 * ============================================================
 *  ANSWERS TO ASSIGNMENT QUESTIONS (in comments as required)
 * ============================================================
 *
 * Q1. What happens with long input (30+ characters)?
 * A1. When input exceeds 15 characters (16 bytes minus null terminator),
 *     strcpy() writes beyond buffer[] and overwrites adjacent stack memory.
 *     This can corrupt other local variables (like admin_flag above),
 *     the saved frame pointer, and the return address of the function.
 *     Possible symptoms:
 *       - admin_flag shows garbled characters
 *       - Segmentation fault (SIGSEGV) when the function tries to return
 *       - Stack smashing detected (if compiled with -fstack-protector)
 *
 * Q2. Why is this dangerous?
 * A2. Buffer overflows are dangerous for several reasons:
 *       a) Arbitrary code execution: An attacker can overwrite the return
 *          address with the address of their own shellcode, causing the
 *          program to jump to and execute malicious code.
 *       b) Privilege escalation: If the vulnerable program runs as root (SUID),
 *          the attacker inherits those elevated privileges.
 *       c) Data corruption: Adjacent variables (e.g., auth flags, pointers)
 *          are silently corrupted, leading to logic errors or bypassed checks.
 *       d) Denial of Service: Overwriting the return address with an invalid
 *          address crashes the program (SIGSEGV).
 *       Buffer overflows are the root cause of many famous exploits
 *       (e.g., Morris Worm 1988, MS Blaster 2003).
 *
 * Q3. How would you fix it?
 * A3. Several mitigations exist – apply them in combination:
 *
 *     Option A – Use strncpy() (bounds-limited copy):
 *         strncpy(buffer, input, sizeof(buffer) - 1);
 *         buffer[sizeof(buffer) - 1] = '\0';   // ensure null termination
 *
 *     Option B – Use snprintf() (safer, handles null-termination):
 *         snprintf(buffer, sizeof(buffer), "%s", input);
 *
 *     Option C – Use strlcpy() (OpenBSD/macOS; always null-terminates):
 *         strlcpy(buffer, input, sizeof(buffer));
 *
 *     Option D – Compiler/OS protections (defence in depth):
 *         - Stack canaries:  gcc -fstack-protector-strong
 *         - ASLR: enabled by default on modern Linux (randomises addresses)
 *         - NX/DEP bit: marks stack memory as non-executable
 *         - FORTIFY_SOURCE: gcc -D_FORTIFY_SOURCE=2 -O2
 *
 *     Best practice: validate ALL user input, prefer safe library functions,
 *     and compile with full security hardening flags.
 * ============================================================
 */
