/*
 * c_port_scanner.c
 * CampusPe Cybersecurity Assignment - Section 4, Task 4.3
 *
 * Simple TCP port scanner using POSIX sockets.
 * Scans ports 22, 80, 443, 3306 on localhost (127.0.0.1).
 *
 * Compile : gcc c_port_scanner.c -o c_port_scanner
 * Run     : ./c_port_scanner
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

/* POSIX socket headers */
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/select.h>

/* ── Configuration ──────────────────────────────────────────────────────── */
#define TARGET_IP   "127.0.0.1"
#define TIMEOUT_SEC  1          /* seconds to wait for connection */
#define NUM_PORTS    4

/* Ports to scan and their associated service names */
static const int   PORTS[]    = { 22, 80, 443, 3306 };
static const char *SERVICES[] = { "SSH", "HTTP", "HTTPS", "MySQL" };


/* ── scan_port() ─────────────────────────────────────────────────────────
 * Attempts a non-blocking TCP connect to ip:port.
 * Returns  1 if port is OPEN
 *          0 if port is CLOSED / filtered / unreachable
 * ────────────────────────────────────────────────────────────────────── */
int scan_port(const char *ip, int port)
{
    int                sockfd;
    struct sockaddr_in target_addr;
    int                flags, ret;
    fd_set             write_fds;
    struct timeval     tv;

    /* 1. Create TCP socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return 0;
    }

    /* 2. Set socket to non-blocking mode so connect() returns immediately */
    flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

    /* 3. Build destination address structure */
    memset(&target_addr, 0, sizeof(target_addr));
    target_addr.sin_family      = AF_INET;
    target_addr.sin_port        = htons((unsigned short)port);

    if (inet_pton(AF_INET, ip, &target_addr.sin_addr) <= 0) {
        fprintf(stderr, "[!] Invalid IP address: %s\n", ip);
        close(sockfd);
        return 0;
    }

    /* 4. Initiate non-blocking connect */
    ret = connect(sockfd, (struct sockaddr *)&target_addr, sizeof(target_addr));

    if (ret == 0) {
        /* Immediate success (rare on non-loopback) */
        close(sockfd);
        return 1;
    }

    if (errno != EINPROGRESS) {
        /* Hard error – port definitely closed / refused */
        close(sockfd);
        return 0;
    }

    /* 5. Wait for socket to become writable (connection established or failed) */
    FD_ZERO(&write_fds);
    FD_SET(sockfd, &write_fds);
    tv.tv_sec  = TIMEOUT_SEC;
    tv.tv_usec = 0;

    ret = select(sockfd + 1, NULL, &write_fds, NULL, &tv);

    if (ret <= 0) {
        /* Timeout (0) or error (<0) */
        close(sockfd);
        return 0;
    }

    /* 6. Check whether the connection actually succeeded */
    int       sock_err = 0;
    socklen_t len      = sizeof(sock_err);
    getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &sock_err, &len);

    close(sockfd);
    return (sock_err == 0) ? 1 : 0;
}


/* ── main() ─────────────────────────────────────────────────────────────── */
int main(void)
{
    int i;
    int open_count = 0;

    printf("\n========================================\n");
    printf("  C Port Scanner\n");
    printf("  Target: %s\n", TARGET_IP);
    printf("========================================\n\n");

    clock_t start = clock();

    for (i = 0; i < NUM_PORTS; i++) {
        int port    = PORTS[i];
        int is_open = scan_port(TARGET_IP, port);

        if (is_open) {
            printf("  Port %4d (%s):\tOPEN\n", port, SERVICES[i]);
            open_count++;
        } else {
            printf("  Port %4d (%s):\tCLOSED\n", port, SERVICES[i]);
        }
    }

    double elapsed = (double)(clock() - start) / CLOCKS_PER_SEC;

    printf("\n========================================\n");
    printf("  Scan complete in %.2f seconds\n", elapsed);
    printf("  Open: %d / %d ports\n", open_count, NUM_PORTS);
    printf("========================================\n\n");

    return 0;
}
