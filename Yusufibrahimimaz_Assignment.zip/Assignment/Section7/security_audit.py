#!/usr/bin/env python3
"""
security_audit.py - Integrated Security Audit Tool
CampusPe Cybersecurity Assignment - Section 7 (Bonus)

Combines:
  - Port scanning (TCP connect scan)
  - Service identification
  - Known-vulnerability database lookup
  - HTML report generation

Usage:
    python3 security_audit.py <target_ip>
    python3 security_audit.py 192.168.1.1
    python3 security_audit.py scanme.nmap.org
"""

import socket
import sys
import time
import os
from datetime import datetime

# ── ANSI colours ─────────────────────────────────────────────────────────────
RED    = "\033[91m";  GREEN  = "\033[92m"
YELLOW = "\033[93m";  CYAN   = "\033[96m"
RESET  = "\033[0m";   BOLD   = "\033[1m"

# ── Service map: port → (service_name, default_banner_keyword) ────────────────
SERVICE_MAP = {
    21:   ("FTP",        "vsftpd"),
    22:   ("SSH",        "OpenSSH"),
    23:   ("Telnet",     "telnetd"),
    25:   ("SMTP",       "Postfix"),
    53:   ("DNS",        "BIND"),
    80:   ("HTTP",       "Apache/nginx"),
    110:  ("POP3",       "Dovecot"),
    143:  ("IMAP",       "Dovecot"),
    443:  ("HTTPS",      "Apache/nginx"),
    445:  ("SMB",        "Samba"),
    3306: ("MySQL",      "MySQL"),
    3389: ("RDP",        "MS Terminal Services"),
    5432: ("PostgreSQL", "PostgreSQL"),
    6379: ("Redis",      "Redis"),
    8080: ("HTTP-Alt",   "Tomcat/Jetty"),
    8443: ("HTTPS-Alt",  "Tomcat"),
    27017:("MongoDB",    "MongoDB"),
}

SCAN_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445,
              3306, 3389, 5432, 6379, 8080, 8443, 27017]
TIMEOUT    = 1.5

# ── Hardcoded vulnerability database ─────────────────────────────────────────
# Format: { port: [ {id, severity, description, recommendation} ] }
VULN_DB = {
    21: [
        {
            "id":          "CVE-ANON-FTP",
            "severity":    "HIGH",
            "description": "Anonymous FTP login may be enabled, allowing unauthenticated file access.",
            "fix":         "Disable anonymous FTP. Require authentication. Prefer SFTP/SCP.",
        },
        {
            "id":          "FTP-CLEARTEXT",
            "severity":    "MEDIUM",
            "description": "FTP transmits credentials in cleartext, vulnerable to sniffing.",
            "fix":         "Replace FTP with SFTP (SSH File Transfer Protocol) or FTPS.",
        },
    ],
    22: [
        {
            "id":          "SSH-ROOT-LOGIN",
            "severity":    "MEDIUM",
            "description": "SSH may allow direct root login, increasing attack surface.",
            "fix":         "Set 'PermitRootLogin no' in /etc/ssh/sshd_config. Use sudo instead.",
        },
        {
            "id":          "SSH-WEAK-CIPHERS",
            "severity":    "LOW",
            "description": "Older SSH configurations may support weak ciphers (RC4, DES).",
            "fix":         "Restrict ciphers to AES-256-CTR, AES-256-GCM in sshd_config.",
        },
    ],
    23: [
        {
            "id":          "TELNET-CLEARTEXT",
            "severity":    "CRITICAL",
            "description": "Telnet transmits ALL data (including passwords) in cleartext.",
            "fix":         "Immediately disable Telnet. Replace with SSH for remote access.",
        },
    ],
    25: [
        {
            "id":          "SMTP-OPEN-RELAY",
            "severity":    "HIGH",
            "description": "SMTP open relay allows spammers to send email through this server.",
            "fix":         "Configure SMTP authentication. Restrict relay to authorised hosts only.",
        },
    ],
    80: [
        {
            "id":          "HTTP-NO-TLS",
            "severity":    "MEDIUM",
            "description": "HTTP traffic is unencrypted. Credentials and data visible to sniffers.",
            "fix":         "Redirect all HTTP traffic to HTTPS. Deploy a valid TLS certificate.",
        },
        {
            "id":          "HTTP-MISSING-HEADERS",
            "severity":    "LOW",
            "description": "Web server may be missing security headers (CSP, X-Frame-Options).",
            "fix":         "Add Content-Security-Policy, X-Frame-Options, X-XSS-Protection headers.",
        },
    ],
    443: [
        {
            "id":          "TLS-OLD-VERSIONS",
            "severity":    "MEDIUM",
            "description": "Server may support deprecated TLS 1.0/1.1 or SSLv3 (POODLE, BEAST).",
            "fix":         "Disable TLS < 1.2. Prefer TLS 1.3. Test with ssl-enum-ciphers NSE script.",
        },
    ],
    445: [
        {
            "id":          "CVE-2017-0144",
            "severity":    "CRITICAL",
            "description": "SMBv1 EternalBlue vulnerability (WannaCry/NotPetya ransomware vector).",
            "fix":         "Disable SMBv1 immediately. Apply MS17-010 patch. Block port 445 externally.",
        },
    ],
    3306: [
        {
            "id":          "MYSQL-REMOTE-ROOT",
            "severity":    "CRITICAL",
            "description": "MySQL exposed to network. Remote root login may be enabled.",
            "fix":         "Bind MySQL to 127.0.0.1 only. Remove remote root access. Use strong passwords.",
        },
    ],
    3389: [
        {
            "id":          "RDP-BLUEKEEP",
            "severity":    "CRITICAL",
            "description": "CVE-2019-0708 (BlueKeep): Unauthenticated RCE via RDP on older Windows.",
            "fix":         "Apply MS patch KB4499175. Enable NLA. Restrict RDP access via VPN/firewall.",
        },
        {
            "id":          "RDP-BRUTE",
            "severity":    "HIGH",
            "description": "RDP exposed to internet is a common brute-force target.",
            "fix":         "Change default port. Implement account lockout. Use VPN for RDP access.",
        },
    ],
    5432: [
        {
            "id":          "POSTGRES-REMOTE",
            "severity":    "HIGH",
            "description": "PostgreSQL exposed to network. Trust authentication may be misconfigured.",
            "fix":         "Bind to localhost unless remote access required. Use strong pg_hba.conf rules.",
        },
    ],
    6379: [
        {
            "id":          "REDIS-NO-AUTH",
            "severity":    "CRITICAL",
            "description": "Redis commonly deployed without authentication, allowing full data access.",
            "fix":         "Set 'requirepass' in redis.conf. Bind to 127.0.0.1. Never expose to internet.",
        },
    ],
    27017: [
        {
            "id":          "MONGO-NO-AUTH",
            "severity":    "CRITICAL",
            "description": "MongoDB historically shipped with authentication disabled by default.",
            "fix":         "Enable MongoDB auth. Use --auth flag. Bind to localhost in mongod.conf.",
        },
    ],
}

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
SEVERITY_COLOUR = {
    "CRITICAL": "#dc2626",
    "HIGH":     "#ea580c",
    "MEDIUM":   "#d97706",
    "LOW":      "#16a34a",
    "INFO":     "#2563eb",
}


# ═══════════════════════════════════════════════════════════════════════════════
# CORE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def scan_port(host: str, port: int, timeout: float = TIMEOUT) -> tuple:
    """TCP connect scan. Returns (port, is_open, banner)."""
    banner = ""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        if result == 0:
            try:
                sock.sendall(b"\r\n")
                raw = sock.recv(256).decode("utf-8", errors="ignore").strip()
                banner = raw.split("\n")[0][:60] if raw else ""
            except Exception:
                pass
            sock.close()
            return port, True, banner
        sock.close()
        return port, False, ""
    except Exception:
        return port, False, ""


def identify_service(port: int, banner: str) -> str:
    """Return the service name for a port."""
    if port in SERVICE_MAP:
        return SERVICE_MAP[port][0]
    try:
        return socket.getservbyport(port)
    except Exception:
        return "Unknown"


def check_vulns(port: int) -> list:
    """Return known vulnerabilities for a port from the hardcoded DB."""
    return VULN_DB.get(port, [])


def run_audit(target: str) -> dict:
    """Full audit: resolve → scan → identify → check vulns."""
    print(f"\n{BOLD}{CYAN}{'='*58}{RESET}")
    print(f"{BOLD}{CYAN}   Security Audit Tool – CampusPe Assignment{RESET}")
    print(f"{BOLD}{CYAN}{'='*58}{RESET}")

    # Resolve
    try:
        ip = socket.gethostbyname(target)
    except socket.gaierror:
        print(f"{RED}[!] Cannot resolve: {target}{RESET}")
        sys.exit(1)

    print(f"\n  Target   : {target} ({ip})")
    print(f"  Ports    : {len(SCAN_PORTS)}")
    print(f"  Started  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    start = time.time()
    findings = []
    open_ports = []

    for port in SCAN_PORTS:
        p, is_open, banner = scan_port(ip, port)
        service = identify_service(p, banner)

        if is_open:
            open_ports.append(p)
            vulns = check_vulns(p)
            print(f"  {GREEN}[OPEN]{RESET}   Port {p:<6} ({service})"
                  + (f"  [{banner[:35]}]" if banner else "")
                  + (f"  → {RED}{len(vulns)} vuln(s){RESET}" if vulns else ""))
            findings.append({
                "port": p, "service": service, "banner": banner, "vulns": vulns
            })
        else:
            print(f"  {RED}[CLOSED]{RESET} Port {p:<6} ({service})")

    elapsed = time.time() - start
    print(f"\n  Scan done in {elapsed:.2f}s  |  Open: {len(open_ports)} / {len(SCAN_PORTS)}\n")

    return {
        "target":  target,
        "ip":      ip,
        "date":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed": elapsed,
        "total_scanned": len(SCAN_PORTS),
        "open_ports": open_ports,
        "findings": findings,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# HTML REPORT GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def generate_html_report(audit: dict, filename: str = "sample_report.html") -> str:
    """Generate a styled HTML security report from audit results."""

    total_vulns = sum(len(f["vulns"]) for f in audit["findings"])
    critical    = sum(1 for f in audit["findings"]
                      for v in f["vulns"] if v["severity"] == "CRITICAL")
    high        = sum(1 for f in audit["findings"]
                      for v in f["vulns"] if v["severity"] == "HIGH")

    # Build findings HTML
    findings_html = ""
    for finding in sorted(audit["findings"],
                          key=lambda x: min(
                              (SEVERITY_ORDER.get(v["severity"], 99) for v in x["vulns"]),
                              default=99)):
        port    = finding["port"]
        service = finding["service"]
        banner  = finding["banner"]
        vulns   = finding["vulns"]

        badge_colour = "#16a34a"
        if any(v["severity"] == "CRITICAL" for v in vulns):
            badge_colour = "#dc2626"
        elif any(v["severity"] == "HIGH" for v in vulns):
            badge_colour = "#ea580c"
        elif any(v["severity"] == "MEDIUM" for v in vulns):
            badge_colour = "#d97706"

        vuln_rows = ""
        if vulns:
            for v in sorted(vulns, key=lambda x: SEVERITY_ORDER.get(x["severity"], 99)):
                sc = SEVERITY_COLOUR.get(v["severity"], "#888")
                vuln_rows += f"""
                <tr>
                  <td><span class="badge" style="background:{sc}20;color:{sc};border:1px solid {sc}">
                      {v['id']}</span></td>
                  <td><strong style="color:{sc}">{v['severity']}</strong></td>
                  <td>{v['description']}</td>
                  <td>{v['fix']}</td>
                </tr>"""
        else:
            vuln_rows = """<tr><td colspan="4" style="color:#6b7280;text-align:center">
                No known vulnerabilities in database</td></tr>"""

        findings_html += f"""
        <div class="finding-card">
          <div class="finding-header">
            <div>
              <span class="port-badge" style="background:{badge_colour}20;
                    color:{badge_colour};border:1px solid {badge_colour}">
                PORT {port}
              </span>
              <strong style="font-size:1.05rem;margin-left:.6rem">{service}</strong>
              {f'<span class="banner-text">{banner}</span>' if banner else ''}
            </div>
            <span style="color:#6b7280;font-size:.85rem">{len(vulns)} finding(s)</span>
          </div>
          <table class="vuln-table">
            <thead>
              <tr><th>ID</th><th>Severity</th><th>Description</th><th>Recommendation</th></tr>
            </thead>
            <tbody>{vuln_rows}</tbody>
          </table>
        </div>"""

    open_list_html = "".join(
        f'<span class="open-port-pill">{p}</span>' for p in audit["open_ports"]
    ) or "<em style='color:#6b7280'>None</em>"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Security Audit Report – {audit['target']}</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: 'Segoe UI', system-ui, sans-serif;
      background: #f9fafb;
      color: #111827;
      padding: 2rem;
    }}
    .report-header {{
      background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
      color: white;
      padding: 2rem 2.5rem;
      border-radius: 12px;
      margin-bottom: 2rem;
    }}
    .report-header h1 {{ font-size: 1.6rem; margin-bottom: .3rem; }}
    .report-header p  {{ opacity: .75; font-size: .9rem; }}
    .meta-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }}
    .meta-card {{
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 10px;
      padding: 1rem 1.2rem;
      text-align: center;
    }}
    .meta-card .value {{
      font-size: 2rem;
      font-weight: 700;
      line-height: 1;
      margin-bottom: .25rem;
    }}
    .meta-card .label {{ font-size: .78rem; color: #6b7280; text-transform: uppercase; }}
    .section-title {{ font-size: 1.1rem; font-weight: 600; margin: 1.5rem 0 .8rem; color: #374151; }}
    .open-ports-wrap {{
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 10px;
      padding: 1rem 1.3rem;
      margin-bottom: 2rem;
      display: flex;
      flex-wrap: wrap;
      gap: .5rem;
      align-items: center;
    }}
    .open-port-pill {{
      background: #dcfce7; color: #15803d; border: 1px solid #86efac;
      border-radius: 20px; padding: .2rem .8rem; font-size: .85rem; font-weight: 600;
    }}
    .finding-card {{
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 10px;
      margin-bottom: 1.2rem;
      overflow: hidden;
    }}
    .finding-header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: .9rem 1.3rem;
      border-bottom: 1px solid #f3f4f6;
      background: #fafafa;
    }}
    .port-badge {{
      display: inline-block;
      border-radius: 6px;
      padding: .2rem .6rem;
      font-size: .78rem;
      font-weight: 700;
      letter-spacing: .04em;
    }}
    .banner-text {{
      font-family: monospace;
      font-size: .78rem;
      color: #6b7280;
      margin-left: .8rem;
      background: #f3f4f6;
      padding: .1rem .4rem;
      border-radius: 4px;
    }}
    .vuln-table {{ width: 100%; border-collapse: collapse; font-size: .85rem; }}
    .vuln-table th {{
      background: #f9fafb; text-align: left;
      padding: .6rem 1rem; color: #6b7280;
      border-bottom: 1px solid #e5e7eb;
      font-size: .78rem; text-transform: uppercase;
    }}
    .vuln-table td {{ padding: .7rem 1rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; }}
    .vuln-table tr:last-child td {{ border-bottom: none; }}
    .badge {{
      display: inline-block; border-radius: 6px;
      padding: .15rem .5rem; font-size: .78rem; font-weight: 600;
    }}
    .footer {{
      margin-top: 3rem; text-align: center;
      color: #9ca3af; font-size: .8rem;
      border-top: 1px solid #e5e7eb; padding-top: 1.5rem;
    }}
  </style>
</head>
<body>

  <!-- ── Header ─────────────────────────────────────────────────────────── -->
  <div class="report-header">
    <h1>🔒 Security Audit Report</h1>
    <p>Target: <strong>{audit['target']}</strong> ({audit['ip']}) &nbsp;|&nbsp;
       Scanned: <strong>{audit['date']}</strong> &nbsp;|&nbsp;
       Duration: <strong>{audit['elapsed']:.2f}s</strong></p>
  </div>

  <!-- ── Summary Cards ──────────────────────────────────────────────────── -->
  <div class="meta-grid">
    <div class="meta-card">
      <div class="value" style="color:#4f46e5">{audit['total_scanned']}</div>
      <div class="label">Ports Scanned</div>
    </div>
    <div class="meta-card">
      <div class="value" style="color:#16a34a">{len(audit['open_ports'])}</div>
      <div class="label">Open Ports</div>
    </div>
    <div class="meta-card">
      <div class="value" style="color:#ea580c">{total_vulns}</div>
      <div class="label">Total Findings</div>
    </div>
    <div class="meta-card">
      <div class="value" style="color:#dc2626">{critical}</div>
      <div class="label">Critical</div>
    </div>
    <div class="meta-card">
      <div class="value" style="color:#ea580c">{high}</div>
      <div class="label">High</div>
    </div>
  </div>

  <!-- ── Open Ports ─────────────────────────────────────────────────────── -->
  <div class="section-title">Open Ports</div>
  <div class="open-ports-wrap">{open_list_html}</div>

  <!-- ── Detailed Findings ──────────────────────────────────────────────── -->
  <div class="section-title">Detailed Findings (sorted by severity)</div>
  {findings_html if findings_html else
   '<p style="color:#6b7280">No open ports discovered.</p>'}

  <div class="footer">
    Generated by security_audit.py &nbsp;|&nbsp; CampusPe Cybersecurity Assignment &nbsp;|&nbsp;
    {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    <br><em>This report is for educational purposes only. Always obtain proper authorisation before scanning.</em>
  </div>

</body>
</html>"""

    with open(filename, "w", encoding="utf-8") as fh:
        fh.write(html)

    return filename


# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    if len(sys.argv) < 2:
        print(f"\n{YELLOW}Usage: python3 security_audit.py <target_ip_or_hostname>{RESET}")
        print(f"Example: python3 security_audit.py 192.168.1.1\n")
        sys.exit(1)

    target = sys.argv[1]
    audit  = run_audit(target)

    report_file = f"audit_report_{target.replace('.','_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    generate_html_report(audit, report_file)

    print(f"{GREEN}[+] HTML report saved: {report_file}{RESET}\n")


if __name__ == "__main__":
    main()
