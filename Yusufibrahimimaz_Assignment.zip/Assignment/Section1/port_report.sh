#!/bin/bash
# =============================================================
# port_report.sh - Port Scanner Report Script
# Author: CampusPe Cybersecurity Assignment
# Description: Scans common ports on a target IP and saves results
# =============================================================

# ---- Check if target IP argument is provided ----
if [ -z "$1" ]; then
    echo "=========================================="
    echo "  Port Scanner Report - Usage Instructions"
    echo "=========================================="
    echo ""
    echo "  Usage:   ./port_report.sh <target_ip>"
    echo "  Example: ./port_report.sh 192.168.1.1"
    echo ""
    echo "  This script will scan common ports:"
    echo "  21 (FTP), 22 (SSH), 80 (HTTP), 443 (HTTPS), 3306 (MySQL)"
    echo "=========================================="
    exit 1
fi

# ---- Variables ----
TARGET_IP="$1"
DATE=$(date +%Y%m%d_%H%M%S)
OUTPUT_FILE="scan_${TARGET_IP}_${DATE}.txt"
PORTS=(21 22 80 443 3306)
PORT_NAMES=(FTP SSH HTTP HTTPS MySQL)
OPEN_COUNT=0
TIMEOUT=2   # seconds to wait per port

# ---- Banner ----
echo "=========================================="
echo "  Port Scanner Report"
echo "=========================================="
echo "  Target  : $TARGET_IP"
echo "  Date    : $(date)"
echo "  Output  : $OUTPUT_FILE"
echo "=========================================="
echo ""

# ---- Write header to output file ----
{
    echo "=========================================="
    echo "  Port Scan Report"
    echo "=========================================="
    echo "  Target IP : $TARGET_IP"
    echo "  Scan Date : $(date)"
    echo "  Ports     : ${PORTS[*]}"
    echo "=========================================="
    echo ""
} > "$OUTPUT_FILE"

# ---- Scan each port ----
echo "Scanning ports..."
echo ""

for i in "${!PORTS[@]}"; do
    PORT="${PORTS[$i]}"
    NAME="${PORT_NAMES[$i]}"

    # Attempt TCP connection using /dev/tcp (bash built-in)
    (echo >/dev/tcp/"$TARGET_IP"/"$PORT") 2>/dev/null
    STATUS=$?

    if [ $STATUS -eq 0 ]; then
        RESULT="OPEN"
        OPEN_COUNT=$((OPEN_COUNT + 1))
    else
        RESULT="CLOSED"
    fi

    # Display to terminal
    printf "  Port %-5s (%-6s) : %s\n" "$PORT" "$NAME" "$RESULT"

    # Write to file
    printf "  Port %-5s (%-6s) : %s\n" "$PORT" "$NAME" "$RESULT" >> "$OUTPUT_FILE"
done

# ---- Summary ----
echo ""
echo "=========================================="
echo "  SCAN COMPLETE"
echo "  Total Open Ports Found: $OPEN_COUNT / ${#PORTS[@]}"
echo "  Results saved to: $OUTPUT_FILE"
echo "=========================================="

# ---- Write summary to file ----
{
    echo ""
    echo "=========================================="
    echo "  SCAN SUMMARY"
    echo "  Total Ports Scanned : ${#PORTS[@]}"
    echo "  Total Open Ports    : $OPEN_COUNT"
    echo "  Scan Completed at   : $(date)"
    echo "=========================================="
} >> "$OUTPUT_FILE"

exit 0
